exports.config = {
  framework: 'mocha',
  capabilities: {
    browserName: 'chrome'
  },
  baseUrl: '<BaseURL>'
}