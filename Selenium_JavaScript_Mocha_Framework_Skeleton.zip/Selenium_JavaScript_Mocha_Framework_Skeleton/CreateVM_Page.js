function CreateVm(){

// Javcript code to automate VM creation workflow..


}

module.export = CreateVm;